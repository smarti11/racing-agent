(() => {
  const mapEl = document.getElementById("map");
  const gpsStatus = document.getElementById("gps-status");
  const btnLocate = document.getElementById("btn-locate");
  const listKatke = document.getElementById("list-katke");
  const listSharf = document.getElementById("list-sharf");
  const togKatke = document.getElementById("tog-katke");
  const togSharf = document.getElementById("tog-sharf");
  const togPaths = document.getElementById("tog-paths");
  const togFairways = document.getElementById("tog-fairways");
  const btnFly = document.getElementById("btn-fly");
  const btnVideo = document.getElementById("btn-video");
  const videoModal = document.getElementById("video-modal");
  const videoTitle = document.getElementById("video-title");
  const holeVideo = document.getElementById("hole-video");
  const videoClose = document.getElementById("video-close");
  const btnReset = document.getElementById("btn-reset");
  const btnBreaks = document.getElementById("btn-breaks");
  const yardageHud = document.getElementById("yardage-hud");
  const yhHole = document.getElementById("yh-hole");
  const yhYards = document.getElementById("yh-yards");
  const yhFrontWrap = document.getElementById("yh-front-wrap");
  const yhBackWrap = document.getElementById("yh-back-wrap");
  const yhFront = document.getElementById("yh-front");
  const yhBack = document.getElementById("yh-back");
  const yhMeta = document.getElementById("yh-meta");
  const btnCenter = document.getElementById("btn-center");
  const scoreHint = document.getElementById("score-hint");
  const scoreEntry = document.getElementById("score-entry");
  const scoreKicker = document.getElementById("score-kicker");
  const scoreHole = document.getElementById("score-hole");
  const scoreNext = document.getElementById("score-next");
  const scoreCollapse = document.getElementById("score-collapse");
  const scoreMinus = document.getElementById("score-minus");
  const scorePlus = document.getElementById("score-plus");
  const scoreInput = document.getElementById("score-input");
  const scoreMic = document.getElementById("score-mic");
  const scoreHeard = document.getElementById("score-heard");
  const scorePlays = document.getElementById("score-plays");
  const scoreRoll = document.getElementById("score-roll");
  const teeSelect = document.getElementById("tee-select");
  const hcpSelect = document.getElementById("hcp-select");

  const SCORE_KEY = "ou-golf-scores-v1";
  const PLAY_KEY = "ou-golf-playing-v1";
  const TEE_KEY = "ou-golf-tee-v1";
  const HCP_KEY = "ou-golf-hcp-v1";
  const TEE_IDS = ["black", "gold", "bear", "white", "cub", "silver"];
  const COURSE_NAMES = { katke: "Katke-Cousins", sharf: "R&S Sharf" };

  const KATKE = "#3ecf7a";
  const SHARF = "#4ea1ff";
  const PATH = "#f0c14b";
  const M_TO_YD = 1.0936132983377078;

  const map = L.map(mapEl, {
    zoomControl: false,
    attributionControl: true,
    maxZoom: 19,
  }).setView([42.6665, -83.203], 15);

  L.control.zoom({ position: "bottomright" }).addTo(map);

  mapEl.addEventListener("pointerdown", () => {
    if (flying) flyPointer = true;
  });
  mapEl.addEventListener(
    "wheel",
    () => {
      if (flying) flyPointer = true;
    },
    { passive: true }
  );
  map.on("dragstart zoomstart", () => {
    if (!flying || !flyPointer) return;
    stopFlyover();
  });
  map.on("click", (e) => {
    if (!selectedHole || flying) return;
    const el = e.originalEvent && e.originalEvent.target;
    if (
      el &&
      el.closest &&
      el.closest(".leaflet-marker-icon, .leaflet-popup, .hole-label, .fly-btn, .leaflet-control")
    ) {
      return;
    }
    markTarget = e.latlng;
    updateYardageHud();
  });

  L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom: 19,
      attribution: "Tiles © Esri",
    }
  ).addTo(map);

  L.tileLayer(
    "https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png",
    {
      maxZoom: 19,
      opacity: 0.7,
      attribution: "© OSM © CARTO",
    }
  ).addTo(map);

  const layers = {
    boundary: L.layerGroup().addTo(map),
    fairways: L.layerGroup().addTo(map),
    greens: L.layerGroup().addTo(map),
    tees: L.layerGroup().addTo(map),
    paths: L.layerGroup().addTo(map),
    holesKatke: L.layerGroup().addTo(map),
    holesSharf: L.layerGroup().addTo(map),
    labelsKatke: L.layerGroup().addTo(map),
    labelsSharf: L.layerGroup().addTo(map),
    pins: L.layerGroup().addTo(map),
  };

  let holeIndex = { katke: {}, sharf: {} };
  let holeButtons = { katke: {}, sharf: {} };
  let pars = { katke: {}, sharf: {} };
  let card = null;
  let teeId = loadTee();
  let hcpSet = loadHcp();
  let scores = loadScores();
  /** @type {Record<string, Record<number, {lat:number, lon:number, props:object}>>} */
  let greenTargets = { katke: {}, sharf: {} };
  let userMarker = null;
  let userWatch = null;
  let accuracyCircle = null;
  let activeHoleBtn = null;
  let selectedHole = null; // { course, hole }
  let markTarget = null; // a map tap, measured instead of the green
  let markMarker = null;
  let playingCourse = loadPlayingCourse();
  let lastHole = { katke: null, sharf: null };
  let lastUser = null; // { lat, lon, accuracy }
  let aimLine = null;
  let greenMarker = null;
  let recognition = null;
  let listening = false;
  let scoreCollapsed = false;
  let flyToken = 0;
  let flyMarker = null;
  let flying = false;
  let flyPointer = false;
  let flySnap = null;

  function holeIcon(course, num) {
    return L.divIcon({
      className: "",
      html: `<div class="hole-label ${course}">${num}</div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
    });
  }

  async function loadJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error("Failed to load " + path);
    return res.json();
  }

  function metersBetween(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const toRad = (d) => (d * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  function yardsBetween(lat1, lon1, lat2, lon2) {
    return metersBetween(lat1, lon1, lat2, lon2) * M_TO_YD;
  }

  function popupHole(p, liveYards) {
    const live =
      liveYards != null
        ? `<br/><strong>${liveYards} yd</strong> to green (GPS)`
        : "";
    const saved = scores[p.course] && scores[p.course][p.hole];
    const scoreLine = saved != null ? `<br/>Your score: ${saved}` : "";
    const facts = holeFacts(p.course, p.hole);
    const fallback = `Par ${p.par || "—"} · ${p.yards || "—"} yd (Black)`;
    const roll = rollPhrase(p.course, p.hole);
    const rollLine = roll ? `<br/>${roll}` : "";
    return `<strong>${p.courseName} · Hole ${p.hole}</strong><br/>${
      facts || fallback
    }${rollLine}${scoreLine}${live}`;
  }

  let greenSlopes = null;
  let slopeLayer = null;

  function greenSlope(course, hole) {
    const book = greenSlopes && greenSlopes.greens && greenSlopes.greens[course];
    return book ? book[String(hole)] : null;
  }

  function rollPhrase(course, hole) {
    const info = greenSlope(course, hole);
    if (!info) return "";
    const fall = Number(info.fallFt);
    if (!isFinite(fall)) return "";
    if (fall < 0.5) return "Green is nearly level";
    const fallText = fall.toFixed(1).replace(/\.0$/, "") + " ft of fall";
    const target = greenTargets[course] && greenTargets[course][hole];
    let shot = null;
    if (target && target.teeLat != null) {
      const bearing = bearingDeg(
        { lat: target.teeLat, lng: target.teeLon },
        { lat: target.lat, lng: target.lon }
      );
      shot = bearing == null ? null : ((bearing % 360) + 360) % 360;
    }
    if (shot == null || info.downDeg == null) return "Green has " + fallText;
    const rel = ((info.downDeg - shot) % 360 + 360) % 360;
    const away = Math.cos((rel * Math.PI) / 180);
    const toRight = Math.sin((rel * Math.PI) / 180);
    const cross = Math.abs(toRight) >= 0.35;
    const side = toRight >= 0 ? "the right" : "the left";
    let how = "off to " + side;
    if (away >= 0.5) how = cross ? "away from you, off to " + side : "away from you";
    else if (away <= -0.5) how = cross ? "back toward you, off to " + side : "back toward you";
    return "Ball rolls " + how + " · " + fallText;
  }

  function showGreenBreak(course, hole) {
    if (slopeLayer) {
      map.removeLayer(slopeLayer);
      slopeLayer = null;
    }
    const info = greenSlope(course, hole);
    if (!info) {
      if (btnBreaks) btnBreaks.hidden = true;
      return;
    }
    slopeLayer = L.imageOverlay(
      info.image,
      [
        [info.south, info.west],
        [info.north, info.east],
      ],
      { opacity: 1, interactive: false }
    ).addTo(map);
    if (btnBreaks) {
      btnBreaks.hidden = false;
      btnBreaks.setAttribute("aria-pressed", "false");
    }
  }

  function clearGreenBreak() {
    if (slopeLayer) {
      map.removeLayer(slopeLayer);
      slopeLayer = null;
    }
    if (btnBreaks) btnBreaks.hidden = true;
  }

  function zoomGreenBreak() {
    if (!slopeLayer) return;
    map.fitBounds(slopeLayer.getBounds(), { padding: [36, 36], maxZoom: 20 });
    if (btnBreaks) btnBreaks.setAttribute("aria-pressed", "true");
  }

  function liveYardsFor(props) {
    if (!lastUser || !props) return null;
    const t = greenTargets[props.course] && greenTargets[props.course][props.hole];
    if (!t) return null;
    return Math.round(yardsBetween(lastUser.lat, lastUser.lon, t.lat, t.lon));
  }

  function refreshHolePopup(course, hole) {
    const layer = holeIndex[course] && holeIndex[course][hole];
    const t = greenTargets[course] && greenTargets[course][hole];
    if (!layer || !t) return;
    const yds = liveYardsFor(t.props);
    layer.setPopupContent(popupHole(t.props, yds));
  }

  function toLocalMeters(lat, lon, originLat) {
    const latM = 111320;
    const lonM = 111320 * Math.cos((originLat * Math.PI) / 180);
    return { x: lon * lonM, y: lat * latM };
  }

  // Front and back are where the shot from you through the pin enters and leaves the green.
  function greenEdges(userLat, userLon, pinLat, pinLon, ring) {
    if (!ring || ring.length < 4) return null;
    const P = toLocalMeters(userLat, userLon, userLat);
    const C = toLocalMeters(pinLat, pinLon, userLat);
    const dx = C.x - P.x;
    const dy = C.y - P.y;
    const length = Math.hypot(dx, dy);
    if (length < 1) return null;
    const hits = [];
    for (let i = 0; i < ring.length - 1; i += 1) {
      const A = toLocalMeters(ring[i][0], ring[i][1], userLat);
      const B = toLocalMeters(ring[i + 1][0], ring[i + 1][1], userLat);
      const ex = B.x - A.x;
      const ey = B.y - A.y;
      const den = dx * ey - dy * ex;
      if (Math.abs(den) < 1e-6) continue;
      const ax = A.x - P.x;
      const ay = A.y - P.y;
      const t = (ax * ey - ay * ex) / den;
      const u = (ax * dy - ay * dx) / den;
      if (t > 0.001 && u >= -0.0001 && u <= 1.0001) hits.push(t);
    }
    if (hits.length < 2) return null;
    return {
      front: Math.round(Math.min.apply(null, hits) * length * M_TO_YD),
      back: Math.round(Math.max.apply(null, hits) * length * M_TO_YD),
    };
  }

  function assignGreenRings(greensFc) {
    const rings = (greensFc.features || [])
      .map((feature) => {
        const coords =
          feature.geometry &&
          feature.geometry.coordinates &&
          feature.geometry.coordinates[0];
        if (!coords || coords.length < 4) return null;
        const ring = coords.map((c) => [c[1], c[0]]);
        const n = ring.length - 1;
        let lat = 0;
        let lon = 0;
        for (let i = 0; i < n; i += 1) {
          lat += ring[i][0];
          lon += ring[i][1];
        }
        return { ring, lat: lat / n, lon: lon / n };
      })
      .filter(Boolean);
    const pins = [];
    Object.keys(greenTargets).forEach((course) => {
      Object.keys(greenTargets[course]).forEach((hole) => {
        pins.push(greenTargets[course][hole]);
      });
    });
    const pairs = [];
    pins.forEach((pin) => {
      rings.forEach((ring) => {
        pairs.push({
          pin,
          ring,
          d: yardsBetween(pin.lat, pin.lon, ring.lat, ring.lon),
        });
      });
    });
    pairs.sort((a, b) => a.d - b.d);
    const usedPins = new Set();
    const usedRings = new Set();
    pairs.forEach((pair) => {
      if (pair.d > 80 || usedPins.has(pair.pin) || usedRings.has(pair.ring)) return;
      usedPins.add(pair.pin);
      usedRings.add(pair.ring);
      pair.pin.ring = pair.ring.ring;
    });
  }

  function showGreenEdges(edges) {
    const on = !!(edges && !markTarget);
    if (yhFrontWrap) yhFrontWrap.hidden = !on;
    if (yhBackWrap) yhBackWrap.hidden = !on;
    if (!on) return;
    yhFront.textContent = String(edges.front);
    yhBack.textContent = String(edges.back);
  }

  function updateMarkButton() {
    if (!btnCenter) return;
    btnCenter.hidden = !selectedHole || !markTarget;
  }

  function updateYardageHud() {
    paintWind();
    if (!selectedHole) {
      yardageHud.hidden = true;
      showGreenEdges(null);
      updateMarkButton();
      if (aimLine) {
        map.removeLayer(aimLine);
        aimLine = null;
      }
      if (greenMarker) {
        map.removeLayer(greenMarker);
        greenMarker = null;
      }
      if (markMarker) {
        map.removeLayer(markMarker);
        markMarker = null;
      }
      return;
    }

    const { course, hole } = selectedHole;
    const t = greenTargets[course] && greenTargets[course][hole];
    if (!t) {
      yardageHud.hidden = true;
      return;
    }

    yardageHud.hidden = false;
    const hcp = handicapFor(course, hole);
    yhHole.textContent = hcp != null ? `Hole ${hole} · Hcp ${hcp}` : `Hole ${hole}`;

    const scorecard = playsLine(course, hole) || `Par ${t.props.par || "—"} · ${t.props.yards || "—"} black`;

    if (!lastUser) {
      yhYards.textContent = "—";
      showGreenEdges(null);
      updateMarkButton();
      yhMeta.textContent = "Waiting for GPS · " + scorecard;
      return;
    }

    const accYd =
      lastUser.accuracy != null
        ? Math.round(lastUser.accuracy * M_TO_YD)
        : null;
    const gpsBit = "GPS" + (accYd != null ? ` ±${accYd}` : "");
    const centerYds = Math.round(
      yardsBetween(lastUser.lat, lastUser.lon, t.lat, t.lon)
    );
    let yds = centerYds;
    if (markTarget) {
      yds = Math.round(
        yardsBetween(lastUser.lat, lastUser.lon, markTarget.lat, markTarget.lng)
      );
      showGreenEdges(null);
      yhMeta.textContent = gpsBit + " · to the mark · " + scorecard;
    } else {
      const edges = greenEdges(lastUser.lat, lastUser.lon, t.lat, t.lon, t.ring);
      showGreenEdges(edges);
      yhMeta.textContent = gpsBit + " · " + scorecard;
    }
    updateMarkButton();
    yhYards.textContent = String(yds);

    const from = [lastUser.lat, lastUser.lon];
    const to = markTarget
      ? [markTarget.lat, markTarget.lng]
      : [t.lat, t.lon];
    if (!aimLine) {
      aimLine = L.polyline([from, to], {
        color: markTarget ? "#ffb020" : "#ffffff",
        weight: 2,
        opacity: 0.85,
        dashArray: "6 8",
      }).addTo(map);
    } else {
      aimLine.setStyle({ color: markTarget ? "#ffb020" : "#ffffff" });
      aimLine.setLatLngs([from, to]);
      if (!map.hasLayer(aimLine)) aimLine.addTo(map);
    }

    if (markTarget) {
      if (!markMarker) {
        markMarker = L.circleMarker(markTarget, {
          radius: 7,
          color: "#ffb020",
          weight: 2,
          fillColor: "#ffb020",
          fillOpacity: 0.95,
          interactive: false,
        }).addTo(map);
      } else {
        markMarker.setLatLng(markTarget);
        if (!map.hasLayer(markMarker)) markMarker.addTo(map);
      }
    } else if (markMarker) {
      map.removeLayer(markMarker);
      markMarker = null;
    }

    if (!greenMarker) {
      greenMarker = L.circleMarker(to, {
        radius: 7,
        color: "#fff",
        weight: 2,
        fillColor: "#111",
        fillOpacity: 0.95,
      }).addTo(map);
    } else {
      greenMarker.setLatLng(to);
      if (!map.hasLayer(greenMarker)) greenMarker.addTo(map);
    }

    refreshHolePopup(course, hole);
  }

  function addPolygonLayer(fc, group, style) {
    L.geoJSON(fc, { style }).addTo(group);
  }

  function buildHoleButtons(course, listEl) {
    listEl.innerHTML = "";
    for (let n = 1; n <= 18; n += 1) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "hole-btn " + course;
      btn.addEventListener("click", () => focusHole(course, n, btn));
      holeButtons[course][n] = btn;
      listEl.appendChild(btn);
      paintScore(course, n);
    }
    renderTotals(course);
  }

  function holeLatLngs(layer) {
    let pts = layer.getLatLngs ? layer.getLatLngs() : [];
    if (pts.length && Array.isArray(pts[0])) pts = pts[0];
    return pts.filter((p) => p && typeof p.lat === "number");
  }

  function resamplePath(latlngs, steps) {
    if (latlngs.length < 2) return latlngs.slice();
    const seg = [];
    let total = 0;
    for (let i = 1; i < latlngs.length; i += 1) {
      const d = map.distance(latlngs[i - 1], latlngs[i]);
      seg.push(d);
      total += d;
    }
    if (total < 1) return latlngs.slice();
    const out = [];
    for (let s = 0; s <= steps; s += 1) {
      let remain = (total * s) / steps;
      let i = 0;
      while (i < seg.length - 1 && remain > seg[i]) {
        remain -= seg[i];
        i += 1;
      }
      const frac = seg[i] ? Math.min(1, remain / seg[i]) : 0;
      const a = latlngs[i];
      const b = latlngs[i + 1] || a;
      out.push(L.latLng(a.lat + (b.lat - a.lat) * frac, a.lng + (b.lng - a.lng) * frac));
    }
    return out;
  }

  function pointAlong(samples, t) {
    const clamped = Math.max(0, Math.min(1, t));
    const idx = clamped * (samples.length - 1);
    const i = Math.min(samples.length - 2, Math.floor(idx));
    const frac = idx - i;
    const a = samples[i];
    const b = samples[i + 1];
    return L.latLng(a.lat + (b.lat - a.lat) * frac, a.lng + (b.lng - a.lng) * frac);
  }

  const COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  let wind = null;

  function compassName(deg) {
    const turn = ((deg % 360) + 360) % 360;
    return COMPASS[Math.round(turn / 22.5) % 16];
  }

  function shotBearing(course, hole) {
    const t = greenTargets[course] && greenTargets[course][hole];
    if (!t || t.teeLat == null) return null;
    const bearing = bearingDeg(
      { lat: t.teeLat, lng: t.teeLon },
      { lat: t.lat, lng: t.lon }
    );
    return bearing == null ? null : ((bearing % 360) + 360) % 360;
  }

  function windPhrase() {
    if (!wind || wind.mph == null) return "";
    if (wind.mph < 1) return "Calm";
    const gust =
      wind.gust != null && wind.gust >= wind.mph + 3 ? ", gusting to " + wind.gust : "";
    if (wind.deg == null) return "Variable" + gust;
    let shot = null;
    if (selectedHole) shot = shotBearing(selectedHole.course, selectedHole.hole);
    if (shot == null) return "from the " + compassName(wind.deg) + gust;
    const rel = ((wind.deg - shot) % 360 + 360) % 360;
    const into = Math.cos((rel * Math.PI) / 180);
    const fromRight = Math.sin((rel * Math.PI) / 180);
    const cross = Math.abs(fromRight) >= 0.35;
    const side = fromRight >= 0 ? "the right" : "the left";
    let how = "off " + side;
    if (into >= 0.5) how = cross ? "into you, off " + side : "into you";
    else if (into <= -0.5) how = cross ? "helping, off " + side : "helping";
    return how + gust;
  }

  function paintWind() {
    const chip = document.getElementById("wind-chip");
    const arrow = document.getElementById("wind-arrow");
    const degEl = document.getElementById("wind-deg");
    const rhEl = document.getElementById("wind-rh");
    const speedEl = document.getElementById("wind-speed");
    const fromEl = document.getElementById("wind-from");
    if (!chip || !speedEl || !fromEl) return;
    if (!wind) {
      speedEl.textContent = "…";
      fromEl.textContent = "at the course";
      return;
    }
    if (wind.mph == null) {
      speedEl.textContent = "—";
      fromEl.textContent = "Wind unavailable";
      if (arrow) arrow.hidden = true;
      return;
    }
    speedEl.replaceChildren();
    speedEl.append(document.createTextNode(wind.mph < 1 ? "Calm" : String(wind.mph)));
    if (wind.mph >= 1) {
      const unit = document.createElement("span");
      unit.className = "wind-unit";
      unit.textContent = "mph";
      speedEl.append(unit);
    }
    if (degEl) degEl.textContent = wind.deg == null ? "Wind" : wind.deg + "°";
    if (rhEl) rhEl.textContent = wind.rh == null ? "" : wind.rh + "% rh";
    fromEl.textContent = windPhrase();
    if (arrow) {
      arrow.hidden = wind.deg == null || wind.mph < 1;
      if (!arrow.hidden) {
        arrow.style.transform = "rotate(" + ((wind.deg + 180) % 360) + "deg)";
      }
    }
    const spoken = [
      wind.mph < 1 ? "Calm" : wind.mph + " miles per hour",
      wind.deg == null ? "" : "from " + wind.deg + " degrees",
      wind.rh == null ? "" : wind.rh + " percent humidity",
      fromEl.textContent,
    ]
      .filter(Boolean)
      .join(", ");
    chip.setAttribute("aria-label", spoken);
  }

  function mphFromKmh(value) {
    const n = Number(value);
    if (!isFinite(n)) return null;
    return Math.round(n * 0.621371);
  }

  async function loadWind() {
    const res = await fetch("https://api.weather.gov/stations/KPTK/observations/latest", {
      headers: { Accept: "application/geo+json" },
    });
    if (!res.ok) throw new Error("wind");
    const data = await res.json();
    const props = data.properties || {};
    const speed = props.windSpeed && props.windSpeed.value;
    const gust = props.windGust && props.windGust.value;
    const dir = props.windDirection && props.windDirection.value;
    const rh = props.relativeHumidity && props.relativeHumidity.value;
    wind = {
      mph: speed == null ? null : mphFromKmh(speed),
      gust: gust == null ? null : mphFromKmh(gust),
      deg: dir == null ? null : Math.round(Number(dir)),
      rh: rh == null ? null : Math.round(Number(rh)),
    };
    paintWind();
  }

  function startWind() {
    const run = () =>
      loadWind().catch(() => {
        if (!wind) {
          wind = { mph: null, gust: null, deg: null, rh: null };
          paintWind();
        }
      });
    run();
    setInterval(run, 10 * 60 * 1000);
  }

  function bearingDeg(a, b) {
    if (map.distance(a, b) < 0.5) return null;
    const φ1 = (a.lat * Math.PI) / 180;
    const φ2 = (b.lat * Math.PI) / 180;
    const Δλ = ((b.lng - a.lng) * Math.PI) / 180;
    const y = Math.sin(Δλ) * Math.cos(φ2);
    const x =
      Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
    return (Math.atan2(y, x) * 180) / Math.PI + 360;
  }

  function updateFlyButton() {
    if (!btnFly) return;
    btnFly.hidden = !selectedHole;
    if (btnReset) btnReset.hidden = !selectedHole;
    btnFly.textContent = flying ? "Stop" : "Fly over";
    btnFly.setAttribute("aria-pressed", flying ? "true" : "false");
    btnFly.setAttribute(
      "aria-label",
      flying ? "Stop the fly-over" : "Fly over this hole from tee to green"
    );
    updateVideoButton();
  }

  function updateVideoButton() {
    if (!btnVideo) return;
    btnVideo.hidden = !selectedHole;
    if (!selectedHole) return;
    const course = selectedHole.course === "sharf" ? "sharf" : "katke";
    const name = course === "katke" ? "Katke" : "Sharf";
    btnVideo.setAttribute("aria-label", "Play the flyover video for " + name + " hole " + selectedHole.hole);
  }

  const holeVoice = new Audio();

  function voiceFile() {
    if (!selectedHole) return "";
    const course = selectedHole.course === "sharf" ? "sharf" : "katke";
    const tee = TEE_IDS.indexOf(teeId) === -1 ? "black" : teeId;
    return "voice-" + course + "-" + selectedHole.hole + "-" + tee + ".m4a";
  }

  function stopHoleVoice() {
    holeVoice.pause();
    holeVoice.removeAttribute("src");
    holeVoice.load();
  }

  function playSelectedVoice() {
    const file = voiceFile();
    if (!file) return;
    holeVoice.pause();
    holeVoice.src = file;
    holeVoice.muted = holeVideo.muted;
    holeVoice.volume = holeVideo.volume;
    holeVoice.play().catch(() => {});
  }

  function closeHoleVideo() {
    if (!videoModal || videoModal.hidden) return;
    stopHoleVoice();
    if (holeVideo) {
      holeVideo.pause();
      holeVideo.removeAttribute("src");
      holeVideo.load();
    }
    videoModal.hidden = true;
  }

  function playHoleVideo() {
    if (!selectedHole || !holeVideo || !videoModal) return;
    const course = selectedHole.course === "sharf" ? "sharf" : "katke";
    const name = course === "katke" ? "Katke" : "Sharf";
    videoTitle.textContent = name + " hole " + selectedHole.hole;
    holeVideo.src = "flyover-" + course + "-" + selectedHole.hole + ".mp4";
    videoModal.hidden = false;
    playSelectedVoice();
    holeVideo.play().catch(() => {});
  }

  function restoreFlySnap() {
    if (flySnap == null) return;
    map.options.zoomSnap = flySnap;
    flySnap = null;
  }

  function stopFlyover() {
    flyToken += 1;
    flying = false;
    flyPointer = false;
    restoreFlySnap();
    if (flyMarker) {
      map.removeLayer(flyMarker);
      flyMarker = null;
    }
    updateFlyButton();
  }

  function flyOver() {
    if (!selectedHole) return;
    if (flying) {
      stopFlyover();
      return;
    }
    const layer = holeIndex[selectedHole.course][selectedHole.hole];
    const path = layer ? holeLatLngs(layer) : [];
    if (path.length < 2) return;
    const samples = resamplePath(path, 90);
    if (layer) layer.closePopup();
    const meters = map.distance(samples[0], samples[samples.length - 1]);
    const reduceMotion =
      window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const closeZoom = Math.min(19, map.getMaxZoom() || 19);
    const startZoom = map.getZoom();
    const dive = reduceMotion ? 0 : 1600;
    const cruise = reduceMotion
      ? 0
      : Math.max(5200, Math.min(9000, meters * M_TO_YD * 14));
    const duration = Math.max(1, dive + cruise);
    if (flySnap == null) flySnap = map.options.zoomSnap;
    map.options.zoomSnap = 0;
    flying = true;
    flyPointer = false;
    const token = ++flyToken;
    updateFlyButton();
    flyMarker = L.marker(samples[0], {
      icon: L.divIcon({
        className: "fly-marker",
        html: '<div class="fly-chevron"></div>',
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      }),
      interactive: false,
      keyboard: false,
      zIndexOffset: 900,
    }).addTo(map);
    let lastBearing = 0;
    const started = performance.now();

    function frame(now) {
      if (token !== flyToken) return;
      const elapsed = now - started;
      let along = 1;
      let zoom = closeZoom;
      if (elapsed < dive) {
        const u = elapsed / dive;
        const eased = 1 - (1 - u) ** 3;
        along = 0;
        zoom = startZoom + (closeZoom - startZoom) * eased;
      } else if (cruise > 0) {
        const u = Math.min(1, (elapsed - dive) / cruise);
        along = u < 0.5 ? 2 * u * u : 1 - ((-2 * u + 2) ** 2) / 2;
        zoom = closeZoom;
      }
      const here = pointAlong(samples, along);
      const ahead = pointAlong(samples, Math.min(1, Math.max(along, 0.015) + 0.03));
      const brg = bearingDeg(here, ahead);
      if (brg != null) lastBearing = brg % 360;
      map.setView(here, zoom, { animate: false });
      if (flyMarker) {
        flyMarker.setLatLng(here);
        const chevron =
          flyMarker.getElement() && flyMarker.getElement().querySelector(".fly-chevron");
        if (chevron) chevron.style.transform = "rotate(" + lastBearing + "deg)";
      }
      if (elapsed < duration) {
        requestAnimationFrame(frame);
      } else {
        flying = false;
        flyPointer = false;
        restoreFlySnap();
        if (flyMarker) {
          map.removeLayer(flyMarker);
          flyMarker = null;
        }
        updateFlyButton();
      }
    }

    requestAnimationFrame(frame);
  }

  function clearHoleSelection() {
    closeHoleVideo();
    stopFlyover();
    stopListening();
    if (selectedHole) {
      const layer = holeIndex[selectedHole.course] && holeIndex[selectedHole.course][selectedHole.hole];
      if (layer) layer.closePopup();
    }
    document.querySelectorAll(".hole-btn.active").forEach((btn) => btn.classList.remove("active"));
    activeHoleBtn = null;
    selectedHole = null;
    markTarget = null;
    clearGreenBreak();
    lastHole.katke = null;
    lastHole.sharf = null;
    map.closePopup();
    updateYardageHud();
    showScoreEntry();
    updateFlyButton();
    const holes = Object.values(holeIndex[playingCourse] || {});
    if (holes.length) {
      map.fitBounds(L.featureGroup(holes).getBounds(), { padding: [30, 30] });
    }
  }

  function focusHole(course, n, btn) {
    const layer = holeIndex[course][n];
    if (!layer) return;
    closeHoleVideo();
    stopFlyover();
    stopListening();
    markTarget = null;
    if (activeHoleBtn) activeHoleBtn.classList.remove("active");
    if (btn) {
      btn.classList.add("active");
      activeHoleBtn = btn;
    } else {
      const list = course === "katke" ? listKatke : listSharf;
      const match = list.querySelector(`.hole-btn:nth-child(${n})`);
      if (match) {
        match.classList.add("active");
        activeHoleBtn = match;
      }
    }
    selectedHole = { course, hole: n };
    lastHole[course] = n;
    setPlayingCourse(course);
    refreshHolePopup(course, n);
    map.fitBounds(layer.getBounds(), { padding: [40, 40], maxZoom: 17 });
    if (scoreCollapsed) layer.closePopup();
    else layer.openPopup();
    updateYardageHud();
    showScoreEntry();
    updateFlyButton();
    showGreenBreak(course, n);
  }

  function applyToggles() {
    const showK = togKatke.checked;
    const showS = togSharf.checked;
    const showP = togPaths.checked;
    const showF = togFairways.checked;

    setLayer(layers.holesKatke, showK);
    setLayer(layers.labelsKatke, showK);
    setLayer(layers.holesSharf, showS);
    setLayer(layers.labelsSharf, showS);
    setLayer(layers.paths, showP);
    setLayer(layers.fairways, showF);
    setLayer(layers.greens, showF);
    setLayer(layers.tees, showF);
    setLayer(layers.pins, showF);
  }

  function setLayer(group, on) {
    if (on) {
      if (!map.hasLayer(group)) group.addTo(map);
    } else if (map.hasLayer(group)) {
      map.removeLayer(group);
    }
  }

  function setGpsStatus(msg, kind) {
    gpsStatus.textContent = msg;
    gpsStatus.className = "status" + (kind ? " " + kind : "");
  }

  function upsertUser(lat, lon, accuracy) {
    const ll = [lat, lon];
    lastUser = { lat, lon, accuracy };
    if (!userMarker) {
      userMarker = L.marker(ll, {
        icon: L.divIcon({
          className: "",
          html: '<div class="user-dot"></div>',
          iconSize: [16, 16],
          iconAnchor: [8, 8],
        }),
        zIndexOffset: 1000,
      }).addTo(map);
      accuracyCircle = L.circle(ll, {
        radius: accuracy || 20,
        color: "#ff5a3c",
        weight: 1,
        fillColor: "#ff5a3c",
        fillOpacity: 0.12,
      }).addTo(map);
    } else {
      userMarker.setLatLng(ll);
      accuracyCircle.setLatLng(ll);
      accuracyCircle.setRadius(accuracy || 20);
    }
    updateYardageHud();
  }

  function startGps(centerOnFix) {
    if (!navigator.geolocation) {
      setGpsStatus("GPS not available on this device.", "err");
      return;
    }
    setGpsStatus("GPS: locating…");
    if (userWatch != null) navigator.geolocation.clearWatch(userWatch);

    userWatch = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        upsertUser(latitude, longitude, accuracy);
        setGpsStatus(
          "GPS: " +
            latitude.toFixed(5) +
            ", " +
            longitude.toFixed(5) +
            " (±" +
            Math.round(accuracy) +
            " m)",
          "ok"
        );
        if (centerOnFix) {
          map.setView([latitude, longitude], Math.max(map.getZoom(), 17));
          centerOnFix = false;
        }
      },
      (err) => {
        setGpsStatus("GPS error: " + (err.message || "permission denied"), "err");
      },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 15000 }
    );
  }

  async function init() {
    prepareMic();
    buildHoleButtons("katke", listKatke);
    buildHoleButtons("sharf", listSharf);

    const [
      meta,
      boundary,
      fairways,
      greens,
      tees,
      cartpaths,
      holes,
      labels,
      pins,
      cardData,
      slopeData,
    ] = await Promise.all([
      loadJSON("meta.json"),
      loadJSON("boundary.geojson"),
      loadJSON("fairways.geojson"),
      loadJSON("greens.geojson"),
      loadJSON("tees.geojson"),
      loadJSON("cartpaths.geojson"),
      loadJSON("holes.geojson"),
      loadJSON("hole_labels.geojson"),
      loadJSON("pins.geojson"),
      loadJSON("card.json"),
      loadJSON("green_slopes.json"),
    ]);
    card = cardData;
    greenSlopes = slopeData;
    paintAllScores();

    document.getElementById("attrib").textContent =
      meta.attribution + " · Yardages from oakland.edu/golf · Green slope: USGS 3DEP · Imagery © Esri · Voice: Alba, University of Edinburgh";

    L.geoJSON(boundary, {
      style: {
        color: "#ffffff",
        weight: 1.5,
        opacity: 0.55,
        fillColor: "#ffffff",
        fillOpacity: 0.03,
      },
    }).addTo(layers.boundary);

    addPolygonLayer(fairways, layers.fairways, {
      color: "#7CFFB2",
      weight: 0.5,
      fillColor: "#2f8f55",
      fillOpacity: 0.28,
    });
    addPolygonLayer(greens, layers.greens, {
      color: "#b8ff6a",
      weight: 1,
      fillColor: "#78d63d",
      fillOpacity: 0.45,
    });
    addPolygonLayer(tees, layers.tees, {
      color: "#d9c27a",
      weight: 0.5,
      fillColor: "#c7a85a",
      fillOpacity: 0.35,
    });

    L.geoJSON(cartpaths, {
      style(feature) {
        const maint = feature.properties.kind === "maintenance";
        return {
          color: PATH,
          weight: maint ? 2 : 2.5,
          opacity: 0.9,
          dashArray: maint ? "4 6" : null,
        };
      },
      onEachFeature(feature, layer) {
        layer.bindPopup(feature.properties.name || "Path");
      },
    }).addTo(layers.paths);

    L.geoJSON(holes, {
      style(feature) {
        const course = feature.properties.course;
        return {
          color: course === "katke" ? KATKE : SHARF,
          weight: 3.5,
          opacity: 0.95,
        };
      },
      onEachFeature(feature, layer) {
        const p = feature.properties;
        const coords = feature.geometry.coordinates;
        // OSM hole lines end at the green / pin end.
        const end = coords[coords.length - 1];
        const start = coords[0];
        greenTargets[p.course][p.hole] = {
          lon: end[0],
          lat: end[1],
          teeLon: start[0],
          teeLat: start[1],
          props: p,
        };
        if (p.par) pars[p.course][p.hole] = p.par;
        layer.bindPopup(popupHole(p));
        holeIndex[p.course][p.hole] = layer;
        if (p.course === "katke") layer.addTo(layers.holesKatke);
        else layer.addTo(layers.holesSharf);
      },
    });

    L.geoJSON(labels, {
      pointToLayer(feature, latlng) {
        const p = feature.properties;
        return L.marker(latlng, {
          icon: holeIcon(p.course, p.shortLabel),
          interactive: true,
        });
      },
      onEachFeature(feature, layer) {
        const p = feature.properties;
        layer.bindPopup(popupHole(p));
        layer.on("click", () => focusHole(p.course, p.hole));
        if (p.course === "katke") layer.addTo(layers.labelsKatke);
        else layer.addTo(layers.labelsSharf);
      },
    });

    L.geoJSON(pins, {
      pointToLayer(feature, latlng) {
        return L.circleMarker(latlng, {
          radius: 3,
          color: "#fff",
          weight: 1,
          fillColor: "#111",
          fillOpacity: 0.9,
        });
      },
    }).addTo(layers.pins);

    assignGreenRings(greens);

    if (meta.clubhouse) {
      L.marker([meta.clubhouse.lat, meta.clubhouse.lon])
        .addTo(map)
        .bindPopup(
          `<strong>${meta.clubhouse.name}</strong><br/>${meta.clubhouse.address}`
        );
    }

    const allHoleLayers = [
      ...Object.values(holeIndex.katke),
      ...Object.values(holeIndex.sharf),
    ];
    if (allHoleLayers.length) {
      const group = L.featureGroup(allHoleLayers);
      map.fitBounds(group.getBounds(), { padding: [30, 30] });
    }

    applyToggles();
    paintAllScores();
    setPlayingCourse(playingCourse);
    startGps(false);
    startWind();
  }

  function loadTee() {
    try {
      const saved = localStorage.getItem(TEE_KEY);
      if (TEE_IDS.indexOf(saved) !== -1) return saved;
    } catch (err) {
      /* keep the default tee */
    }
    return "black";
  }

  function loadHcp() {
    try {
      if (localStorage.getItem(HCP_KEY) === "women") return "women";
    } catch (err) {
      /* keep the men's card */
    }
    return "men";
  }

  function rememberChoice(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (err) {
      /* Private mode can block storage. */
    }
  }

  function holeCard(course, hole) {
    const holes = card && card.courses && card.courses[course] && card.courses[course].holes;
    if (!holes) return null;
    return holes[hole - 1] || null;
  }

  function teeName(id) {
    const row = card && card.tees && card.tees.find((tee) => tee.id === id);
    if (row) return row.name;
    return id ? id.charAt(0).toUpperCase() + id.slice(1) : "Tee";
  }

  function handicapFor(course, hole) {
    const info = holeCard(course, hole);
    if (!info) return null;
    return hcpSet === "women" ? info.hcpWomen : info.hcpMen;
  }

  function yardageFor(course, hole) {
    const info = holeCard(course, hole);
    if (!info || !info.yards || info.yards[teeId] == null) return null;
    return info.yards[teeId];
  }

  function playsFor(course, hole) {
    const info = holeCard(course, hole);
    if (!info || !info.elevFt) return null;
    return OUScore.playsLike(info.yards[teeId], info.elevFt[teeId], info.elevFt.green);
  }

  function playsLine(course, hole) {
    const yards = yardageFor(course, hole);
    if (yards == null) return "";
    const plays = OUScore.formatPlaysLike(playsFor(course, hole));
    return plays ? teeName(teeId) + " " + yards + " · " + plays : teeName(teeId) + " " + yards;
  }

  function holeFacts(course, hole) {
    const info = holeCard(course, hole);
    const par = (info && info.par) || (pars[course] && pars[course][hole]);
    const hcp = handicapFor(course, hole);
    const bits = [];
    if (par) bits.push("Par " + par);
    if (hcp != null) bits.push("Hcp " + hcp);
    const line = playsLine(course, hole);
    if (line) bits.push(line);
    return bits.join(" · ");
  }

  function saveDetails(course) {
    const holes = {};
    for (let n = 1; n <= 18; n += 1) {
      const plays = playsFor(course, n);
      holes[n] = {
        hcp: handicapFor(course, n),
        teeName: teeName(teeId),
        yards: yardageFor(course, n),
        plays: plays ? plays.yards : null,
      };
    }
    return holes;
  }

  function applyCardChoices() {
    rememberChoice(TEE_KEY, teeId);
    rememberChoice(HCP_KEY, hcpSet);
    paintAllScores();
    ["katke", "sharf"].forEach((course) => {
      for (let n = 1; n <= 18; n += 1) refreshHolePopup(course, n);
    });
    updateYardageHud();
    showScoreEntry();
  }

  function loadPlayingCourse() {
    try {
      const saved = localStorage.getItem(PLAY_KEY);
      if (saved === "sharf" || saved === "katke") return saved;
    } catch (err) {
      /* Private mode can block storage. */
    }
    return "katke";
  }

  function setPlayingCourse(course) {
    if (course !== "katke" && course !== "sharf") course = "katke";
    playingCourse = course;
    try {
      localStorage.setItem(PLAY_KEY, course);
    } catch (err) {
      /* The choice still applies for this visit. */
    }
    const katkePanel = document.getElementById("course-katke");
    const sharfPanel = document.getElementById("course-sharf");
    const panel = course === "katke" ? katkePanel : sharfPanel;
    panel.hidden = false;
    const head = panel.querySelector(".course-head");
    if (head && scoreEntry.parentElement !== panel) {
      head.insertAdjacentElement("afterend", scoreEntry);
    }
    katkePanel.hidden = course !== "katke";
    sharfPanel.hidden = course !== "sharf";
    document.getElementById("play-katke").setAttribute("aria-selected", course === "katke" ? "true" : "false");
    document.getElementById("play-sharf").setAttribute("aria-selected", course === "sharf" ? "true" : "false");
  }

  function showPlayingCourse(course) {
    const remembered = lastHole[course];
    if (remembered && holeIndex[course] && holeIndex[course][remembered]) {
      focusHole(course, remembered);
      return;
    }
    closeHoleVideo();
    stopFlyover();
    stopListening();
    setPlayingCourse(course);
    if (selectedHole && selectedHole.course !== course) {
      if (activeHoleBtn) activeHoleBtn.classList.remove("active");
      activeHoleBtn = null;
      selectedHole = null;
      updateYardageHud();
      updateFlyButton();
    }
    showScoreEntry();
    const holes = Object.values((holeIndex[course]) || {});
    if (holes.length) {
      map.fitBounds(L.featureGroup(holes).getBounds(), { padding: [30, 30] });
    }
  }

  function loadScores() {
    try {
      const raw = JSON.parse(localStorage.getItem(SCORE_KEY) || "{}");
      return { katke: sanitizeCourse(raw.katke), sharf: sanitizeCourse(raw.sharf) };
    } catch (err) {
      return { katke: {}, sharf: {} };
    }
  }

  function sanitizeCourse(raw) {
    const out = {};
    if (!raw || typeof raw !== "object") return out;
    for (let n = 1; n <= 18; n += 1) {
      const value = OUScore.clampStrokes(raw[n] != null ? raw[n] : raw[String(n)]);
      if (value != null) out[n] = value;
    }
    return out;
  }

  function saveScores() {
    try {
      localStorage.setItem(SCORE_KEY, JSON.stringify(scores));
    } catch (err) {
      /* Private mode can block storage; the card still works for this visit. */
    }
  }

  function paintScore(course, hole) {
    const btn = holeButtons[course][hole];
    if (!btn) return;
    const value = scores[course][hole];
    const hcp = handicapFor(course, hole);
    const plays = playsFor(course, hole);
    btn.replaceChildren();
    const num = document.createElement("span");
    num.className = "hb-n";
    num.textContent = String(hole);
    const hcpMark = document.createElement("span");
    hcpMark.className = "hb-h";
    hcpMark.textContent = hcp == null ? "" : "H" + hcp;
    const playsMark = document.createElement("span");
    playsMark.className = "hb-p";
    playsMark.textContent = plays ? String(plays.yards) : "";
    btn.append(num, hcpMark, playsMark);
    if (value != null) {
      const mark = document.createElement("span");
      mark.className = "hb-s";
      mark.textContent = String(value);
      btn.append(mark);
    }
    btn.classList.toggle("scored", value != null);
    const bits = ["Hole " + hole];
    if (hcp != null) bits.push("handicap " + hcp);
    if (plays) bits.push("plays " + plays.yards);
    if (value != null) bits.push(value + " strokes");
    btn.setAttribute("aria-label", bits.join(", "));
  }

  function paintAllScores() {
    ["katke", "sharf"].forEach((course) => {
      for (let n = 1; n <= 18; n += 1) paintScore(course, n);
      renderTotals(course);
    });
  }

  function renderTotals(course) {
    const el = document.getElementById("totals-" + course);
    if (!el) return;
    el.replaceChildren();
    const rows = [
      ["Out", OUScore.nineSummary(scores[course], pars[course], 1, 9), false],
      ["In", OUScore.nineSummary(scores[course], pars[course], 10, 18), false],
      ["18 holes", OUScore.nineSummary(scores[course], pars[course], 1, 18), true],
    ];
    rows.forEach((row) => {
      const cell = document.createElement("div");
      if (row[2]) cell.className = "round-total";
      const label = document.createElement("span");
      label.textContent = row[0];
      const strong = document.createElement("strong");
      strong.textContent = OUScore.formatStrokes(row[1]);
      cell.append(label, strong);
      el.appendChild(cell);
    });
  }

  function showScoreEntry() {
    if (!selectedHole || selectedHole.course !== playingCourse) {
      scoreEntry.hidden = true;
      scoreHint.hidden = false;
      return;
    }
    const course = selectedHole.course;
    const hole = selectedHole.hole;
    const par = pars[course][hole];
    const saved = scores[course][hole];
    scoreEntry.hidden = false;
    scoreHint.hidden = true;
    const hcp = handicapFor(course, hole);
    scoreKicker.textContent = COURSE_NAMES[course] || course;
    scoreHole.textContent =
      "Hole " +
      hole +
      (par ? " · Par " + par : "") +
      (hcp != null ? " · Hcp " + hcp : "") +
      (scoreCollapsed && saved != null ? " · " + saved : "");
    if (scorePlays) scorePlays.textContent = playsLine(course, hole);
    if (scoreRoll) scoreRoll.textContent = rollPhrase(course, hole);
    scoreInput.value = saved == null ? "" : String(saved);
    scoreNext.disabled = hole >= 18;
    scoreNext.textContent = hole >= 18 ? "Last hole" : "Next hole";
    scoreHeard.textContent =
      saved == null
        ? "Say the strokes, or type them."
        : saved + (saved === 1 ? " stroke saved." : " strokes saved.");
    scoreEntry.classList.toggle("is-collapsed", scoreCollapsed);
    scoreCollapse.textContent = scoreCollapsed ? "Score" : "Hide";
    scoreCollapse.setAttribute("aria-expanded", scoreCollapsed ? "false" : "true");
    if (!scoreCollapsed) scoreEntry.scrollIntoView({ block: "nearest" });
  }

  function setScoreCollapsed(collapsed) {
    scoreCollapsed = collapsed;
    if (collapsed) stopListening();
    if (selectedHole) {
      const layer = holeIndex[selectedHole.course][selectedHole.hole];
      if (layer && collapsed) layer.closePopup();
    }
    showScoreEntry();
  }

  function setScore(course, hole, strokes) {
    if (strokes == null) delete scores[course][hole];
    else scores[course][hole] = strokes;
    saveScores();
    setSaveNote(course, "");
    paintScore(course, hole);
    renderTotals(course);
    if (selectedHole && selectedHole.course === course && selectedHole.hole === hole) {
      const shown = strokes == null ? "" : String(strokes);
      if (scoreInput.value !== shown) scoreInput.value = shown;
    }
    refreshHolePopup(course, hole);
  }

  function commitTypedScore() {
    if (!selectedHole) return;
    const raw = scoreInput.value.trim();
    if (raw === "") {
      setScore(selectedHole.course, selectedHole.hole, null);
      scoreHeard.textContent = "Score cleared. Say or type the strokes.";
      return;
    }
    const strokes = OUScore.clampStrokes(raw);
    if (strokes == null) {
      const saved = scores[selectedHole.course][selectedHole.hole];
      scoreInput.value = saved == null ? "" : String(saved);
      scoreHeard.textContent = "Enter 1 to 20 strokes.";
      return;
    }
    setScore(selectedHole.course, selectedHole.hole, strokes);
    scoreHeard.textContent =
      strokes + (strokes === 1 ? " stroke saved." : " strokes saved.");
  }

  function bumpScore(delta) {
    if (!selectedHole) return;
    const course = selectedHole.course;
    const hole = selectedHole.hole;
    const current = scores[course][hole];
    let next;
    if (current == null) {
      if (delta < 0) return;
      next = pars[course][hole] || 4;
    } else {
      next = current + delta;
    }
    next = OUScore.clampStrokes(next);
    if (next == null) return;
    setScore(course, hole, next);
    scoreHeard.textContent =
      next + (next === 1 ? " stroke saved." : " strokes saved.");
  }

  function clearCourse(course) {
    const name = COURSE_NAMES[course] || course;
    if (!window.confirm("Clear all " + name + " scores?")) return;
    scores[course] = {};
    saveScores();
    setSaveNote(course, "");
    for (let n = 1; n <= 18; n += 1) {
      paintScore(course, n);
      refreshHolePopup(course, n);
    }
    renderTotals(course);
    if (selectedHole && selectedHole.course === course) showScoreEntry();
  }

  function setSaveNote(course, message) {
    const note = document.getElementById("save-note-" + course);
    if (note) note.textContent = message || "";
  }

  function downloadScore(filename, text) {
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.rel = "noopener";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  async function saveCourse(course) {
    const button = document.getElementById("save-" + course);
    const name = COURSE_NAMES[course] || course;
    const round = OUScore.nineSummary(scores[course], pars[course], 1, 18);
    if (!round.counted) {
      setSaveNote(course, "Enter a score first.");
      return;
    }
    const now = new Date();
    const dateLabel = now.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    const text = OUScore.scorecardText(name, scores[course], pars[course], dateLabel, {
      heading: teeName(teeId) + " tees · " + (hcpSet === "women" ? "women's" : "men's") + " handicap",
      holes: saveDetails(course),
    });
    const filename = OUScore.scorecardFilename(name, now);
    const file = new File([text], filename, { type: "text/plain" });
    if (button) button.disabled = true;
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: name + " score" });
        setSaveNote(course, "Saved to the place you picked.");
      } else if (navigator.share) {
        await navigator.share({ title: name + " score", text: text });
        setSaveNote(course, "Saved to the place you picked.");
      } else {
        downloadScore(filename, text);
        setSaveNote(course, "Score file downloaded.");
      }
    } catch (err) {
      if (err && err.name === "AbortError") return;
      try {
        downloadScore(filename, text);
        setSaveNote(course, "Score file downloaded.");
      } catch (downloadErr) {
        setSaveNote(course, "Couldn't save. Try again.");
      }
    } finally {
      if (button) button.disabled = false;
    }
  }

  function speechCtor() {
    return window.SpeechRecognition || window.webkitSpeechRecognition || null;
  }

  function prepareMic() {
    if (speechCtor()) return;
    scoreMic.disabled = true;
    scoreMic.textContent = "No mic";
    scoreMic.title = "This browser cannot hear a score. Type the strokes.";
  }

  function stopListening() {
    if (!recognition) return;
    try {
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;
      recognition.abort();
    } catch (err) {
      /* already stopped */
    }
    listening = false;
    scoreMic.classList.remove("listening");
    scoreMic.setAttribute("aria-pressed", "false");
    if (!scoreMic.disabled) scoreMic.textContent = "Say score";
  }

  function listenForScore() {
    const Ctor = speechCtor();
    if (!Ctor || !selectedHole) return;
    if (listening) {
      stopListening();
      scoreHeard.textContent = "Stopped. Say the strokes, or type them.";
      return;
    }
    const course = selectedHole.course;
    const hole = selectedHole.hole;
    const par = pars[course][hole];
    recognition = new Ctor();
    recognition.lang = "en-US";
    recognition.interimResults = true;
    recognition.maxAlternatives = 4;
    recognition.continuous = false;

    recognition.onstart = () => {
      listening = true;
      scoreMic.classList.add("listening");
      scoreMic.setAttribute("aria-pressed", "true");
      scoreMic.textContent = "Listening";
      scoreHeard.textContent = "Listening… say the strokes, like 5, or bogey.";
    };

    recognition.onresult = (event) => {
      let interim = "";
      let finalText = "";
      const finals = [];
      for (let i = 0; i < event.results.length; i += 1) {
        const piece = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalText += piece;
          for (let a = 0; a < event.results[i].length; a += 1) {
            finals.push(event.results[i][a].transcript);
          }
        } else {
          interim += piece;
        }
      }
      if (!finalText.trim()) {
        scoreHeard.textContent = interim.trim()
          ? "Hearing “" + interim.trim() + "”…"
          : "Listening…";
        return;
      }
      const heard = (finals[0] || finalText).trim();
      let strokes = null;
      const candidates = finals.length ? finals : [finalText];
      for (let i = 0; i < candidates.length; i += 1) {
        strokes = OUScore.parseSpokenScore(candidates[i], par);
        if (strokes != null) break;
      }
      if (strokes == null) {
        scoreHeard.textContent = heard
          ? "Heard “" + heard + "”. Say a number of strokes, or type it."
          : "Didn't catch that. Type the strokes.";
        return;
      }
      if (!selectedHole || selectedHole.course !== course || selectedHole.hole !== hole) return;
      setScore(course, hole, strokes);
      scoreHeard.textContent = "Heard “" + heard + "”. Saved " + strokes + ".";
    };

    recognition.onerror = (event) => {
      if (!event || event.error === "aborted") return;
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        scoreHeard.textContent =
          "Microphone is blocked. Type the strokes, or allow the mic for this site.";
      } else if (event.error === "no-speech") {
        scoreHeard.textContent = "Didn't hear a score. Try again, or type the strokes.";
      } else {
        scoreHeard.textContent = "Couldn't use the microphone. Type the strokes.";
      }
    };

    recognition.onend = () => {
      listening = false;
      scoreMic.classList.remove("listening");
      scoreMic.setAttribute("aria-pressed", "false");
      if (!scoreMic.disabled) scoreMic.textContent = "Say score";
    };

    try {
      recognition.start();
    } catch (err) {
      listening = false;
      scoreHeard.textContent = "Couldn't start listening. Type the strokes.";
    }
  }

  togKatke.addEventListener("change", applyToggles);
  togSharf.addEventListener("change", applyToggles);
  togPaths.addEventListener("change", applyToggles);
  togFairways.addEventListener("change", applyToggles);
  document.getElementById("play-katke").addEventListener("click", () => showPlayingCourse("katke"));
  document.getElementById("play-sharf").addEventListener("click", () => showPlayingCourse("sharf"));
  btnLocate.addEventListener("click", () => startGps(true));
  btnFly.addEventListener("click", flyOver);
  if (btnVideo) btnVideo.addEventListener("click", playHoleVideo);
  if (holeVideo) {
    holeVideo.addEventListener("pause", () => holeVoice.pause());
    holeVideo.addEventListener("play", () => {
      if (!holeVoice.src || holeVoice.ended) return;
      holeVoice.play().catch(() => {});
    });
    holeVideo.addEventListener("volumechange", () => {
      holeVoice.muted = holeVideo.muted;
      holeVoice.volume = holeVideo.volume;
    });
  }
  const siteModal = document.getElementById("site-modal");
  const btnSite = document.getElementById("btn-site");
  const siteClose = document.getElementById("site-close");

  function closeSite() {
    if (!siteModal || siteModal.hidden) return;
    siteModal.hidden = true;
  }

  if (btnSite && siteModal) btnSite.addEventListener("click", () => { siteModal.hidden = false; });
  if (siteClose) siteClose.addEventListener("click", closeSite);
  if (siteModal) {
    siteModal.addEventListener("click", (event) => {
      if (event.target === siteModal) closeSite();
    });
  }
  if (videoClose) videoClose.addEventListener("click", closeHoleVideo);
  if (videoModal) {
    videoModal.addEventListener("click", (event) => {
      if (event.target === videoModal) closeHoleVideo();
    });
  }
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (siteModal && !siteModal.hidden) closeSite();
    else closeHoleVideo();
  });
  btnCenter.addEventListener("click", () => {
    markTarget = null;
    updateYardageHud();
  });
  btnReset.addEventListener("click", clearHoleSelection);
  if (btnBreaks) btnBreaks.addEventListener("click", zoomGreenBreak);
  scoreMinus.addEventListener("click", () => bumpScore(-1));
  scorePlus.addEventListener("click", () => bumpScore(1));
  scoreInput.addEventListener("input", () => {
    if (!selectedHole) return;
    const raw = scoreInput.value.trim();
    if (raw === "") {
      setScore(selectedHole.course, selectedHole.hole, null);
      return;
    }
    const strokes = OUScore.clampStrokes(raw);
    if (strokes == null) return;
    setScore(selectedHole.course, selectedHole.hole, strokes);
    scoreHeard.textContent =
      strokes + (strokes === 1 ? " stroke saved." : " strokes saved.");
  });
  scoreInput.addEventListener("blur", commitTypedScore);
  scoreMic.addEventListener("click", listenForScore);
  scoreCollapse.addEventListener("click", () => setScoreCollapsed(!scoreCollapsed));
  scoreNext.addEventListener("click", () => {
    if (!selectedHole || selectedHole.hole >= 18) return;
    focusHole(selectedHole.course, selectedHole.hole + 1);
  });
  document.getElementById("clear-katke").addEventListener("click", () => clearCourse("katke"));
  document.getElementById("clear-sharf").addEventListener("click", () => clearCourse("sharf"));
  document.getElementById("save-katke").addEventListener("click", () => saveCourse("katke"));
  document.getElementById("save-sharf").addEventListener("click", () => saveCourse("sharf"));
  if (teeSelect) {
    teeSelect.value = teeId;
    teeSelect.addEventListener("change", () => {
      if (TEE_IDS.indexOf(teeSelect.value) === -1) return;
      teeId = teeSelect.value;
      applyCardChoices();
      if (videoModal && !videoModal.hidden) playSelectedVoice();
    });
  }
  if (hcpSelect) {
    hcpSelect.value = hcpSet;
    hcpSelect.addEventListener("change", () => {
      hcpSet = hcpSelect.value === "women" ? "women" : "men";
      applyCardChoices();
    });
  }

  setPlayingCourse(playingCourse);

  init().catch((err) => {
    console.error(err);
    setGpsStatus("Could not load course map data.", "err");
  });
})();
